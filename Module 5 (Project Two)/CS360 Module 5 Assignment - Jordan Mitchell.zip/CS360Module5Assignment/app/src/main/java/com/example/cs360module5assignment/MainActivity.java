package com.example.cs360module5assignment;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;
import android.text.Editable;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.constraintLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Find views
        EditText nameText = findViewById(R.id.nameText);
        Button buttonSayHello = findViewById(R.id.buttonSayHello);

        // Watch text for changes in the nameText field
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No action required before text changes
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable or disable the button based on presence of text
                buttonSayHello.setEnabled(!s.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No action required after changes
            }
        });
    }
    public void SayHello(View view) {
        // Find nameText and textGreeting views
        EditText nameText = findViewById(R.id.nameText);
        TextView textGreeting = findViewById(R.id.textGreeting);

        // Get text from nameText
        String name = nameText.getText().toString();

        // Check if nameText is empty/null
        if (name == null || name.trim().isEmpty()) {
            // Do nothing if there's no name
            return;
        }

        // Update textGreeting with greeting
        textGreeting.setText("Hello " + name);
    }
}